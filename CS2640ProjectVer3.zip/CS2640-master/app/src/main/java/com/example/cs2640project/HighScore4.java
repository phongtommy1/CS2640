package com.example.cs2640project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HighScore4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_score4);


    }
}